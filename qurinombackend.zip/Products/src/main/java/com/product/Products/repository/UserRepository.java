package com.product.Products.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.product.Products.model.User;

public interface UserRepository extends JpaRepository<User, Long> {

	User findByUsername(String usernamesString);

}
