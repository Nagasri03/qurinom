package com.product.Products.service.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.product.Products.model.Product;
import com.product.Products.repository.ProductRepository;

import jakarta.persistence.EntityNotFoundException;
@Service
public class ProductServiceImpl {
	 @Autowired
	private ProductRepository productRepository;
	 
	public Product createProduct(Product product) {
	    return productRepository.save(product);
	}
	public Product updateProduct(Product product) {
	    return productRepository.save(product);
	}
	public Product likeProduct(Long productId) {
	    Product product = productRepository.findById(productId)
	            .orElseThrow(() -> new EntityNotFoundException("Product not found"));

	    int currentLikes = product.getLikes();
	    product.setLikes(currentLikes + 1);

	    return productRepository.save(product);
	}
	public Product unlikeProduct(Long productId) {
	    Product product = productRepository.findById(productId)
	            .orElseThrow(() -> new EntityNotFoundException("Product not found"));

	    int currentLikes = product.getLikes();
	    product.setLikes(Math.max(0, currentLikes-1));

	    return productRepository.save(product);
	}
	public List<Product> searchProducts(String category, String tags) {
	   
	    if (category != null && tags != null) {
	        return productRepository.findByCategoryAndTags(category, tags);
	    } else if (category != null) {
	        return productRepository.findByCategory(category);
	    } else if (tags != null) {
	        return productRepository.findByTags(tags);
	    } else {
	        return productRepository.findAll();
	    }
	}
	public Product updateProduct(Long productId, Product updatedProduct) {
	    Product existingProduct = productRepository.findById(productId)
	            .orElseThrow(() -> new EntityNotFoundException("Product not found"));

	    existingProduct.setName(updatedProduct.getName());
	    existingProduct.setCategory(updatedProduct.getCategory());
	    existingProduct.setTags(updatedProduct.getTags());
	    existingProduct.setLikes(updatedProduct.getLikes());

	    return productRepository.save(existingProduct);
	}

}
