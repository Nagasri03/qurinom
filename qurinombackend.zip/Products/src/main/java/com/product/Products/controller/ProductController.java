package com.product.Products.controller;

import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.product.Products.model.Product;
import com.product.Products.service.serviceimpl.ProductServiceImpl;
import com.product.Products.service.serviceimpl.UserServiceImpl;
@CrossOrigin(origins={"*"})
@RestController
@RequestMapping("/api/products")
public class ProductController {
    @Autowired
    private ProductServiceImpl productService;
    @Autowired
    private UserServiceImpl userServiceImpl;
    @PostMapping("create/user")
	public ResponseEntity<String> createUser(@RequestBody Map<String, String> user) throws NoSuchAlgorithmException{
		return userServiceImpl.createUser(user);
	}
	
	@PostMapping("login/user")
	public ResponseEntity<String> loginUser(@RequestBody Map<String, String> user) throws NoSuchAlgorithmException{
		return userServiceImpl.loginUser(user);
	}
    @PostMapping("/create")
    public Product createProduct(@RequestBody Product product) {
        return productService.createProduct(product);
    }

    @PostMapping("/{productId}/like")
    public Product likeProduct(@PathVariable Long productId) {
        return productService.likeProduct(productId);
    }

    @PostMapping("/{productId}/unlike")
    public Product unlikeProduct(@PathVariable Long productId) {
        return productService.unlikeProduct(productId);
    }

    @GetMapping("/search")
    public List<Product> searchProducts(@RequestParam(required = false) String category, @RequestParam(required = false) String tags) {
        return productService.searchProducts(category, tags);
    }

    @PostMapping("/update")
    public Product updateProduct(@RequestBody Product product) {
        return productService.updateProduct(product);
    }
}
