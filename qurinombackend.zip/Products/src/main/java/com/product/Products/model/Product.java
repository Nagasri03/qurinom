package com.product.Products.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="products")
public class Product {
	 @Id
	@Column
	 private Long id;
	 @Column
	 private String name;
	 @Column
	 private String category;
	 @Column
	 private String tags;
	 @Column
	 private int likes;
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	public Product(Long id, String name, String category, String tags, int likes) {
		super();
		this.id = id;
		this.name = name;
		this.category = category;
		this.tags = tags;
		this.likes = likes;
	}



	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getTags() {
		return tags;
	}
	public void setTags(String tags) {
		this.tags = tags;
	}

	public int getLikes() {
		return likes;
	}



	public void setLikes(int likes) {
		this.likes = likes;
	}



	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", category=" + category + ", tags=" + tags + ", likes=" + likes
				+ "]";
	}

	
	
	
}
